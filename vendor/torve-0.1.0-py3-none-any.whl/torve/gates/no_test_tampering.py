"""`no-test-tampering` — tests edited where the task did not license it
(RFC 0002 §4).

A test edit is licensed when the file falls inside the task's `scope.allow`
(an empty allow licenses everything, and is already loud in task review).
Adding a brand-new test file is not tampering; modifying or deleting an
existing one is what weakens a suite. Without a task there is no licence to
check against, so the gate reports skipped, never green.
"""

from __future__ import annotations

from torve.config.manifest import Gate
from torve.gates.context import GateContext
from torve.gates.contract import NO_TASK, BuiltinOutcome, spec

# ----------------------- #


def check_no_test_tampering(gate: Gate, ctx: GateContext) -> BuiltinOutcome:
    if ctx.task is None:
        return NO_TASK

    # Both specs compiled once, not per path in the loop below.
    tests = spec(ctx.manifest.tests.patterns) if ctx.manifest.tests.patterns else None
    allow = spec(ctx.task.scope.allow) if ctx.task.scope.allow else None

    if tests is None:
        return BuiltinOutcome("pass", "no test patterns configured; nothing to protect")

    unlicensed: list[str] = []

    for entry in ctx.diff:
        if entry.status == "A":
            continue

        paths = [p for p in (entry.path, entry.old_path) if p]

        for path in paths:
            if not tests.match_file(path):
                continue

            if allow is not None and not allow.match_file(path):
                unlicensed.append(f"{entry.status} {path}")

    if not unlicensed:
        return BuiltinOutcome("pass", "no unlicensed edits to existing tests")

    lines = ["test files edited outside the task's scope.allow:"]
    lines += sorted(set(unlicensed))

    return BuiltinOutcome("fail", "\n".join(lines))
